#ifndef DOUBLELINKEDLIST_H
#define DOUBLELINKEDLIST_H

#include "queue.h"
#include <stdexcept>

template <typename Object>
class DoubleLinkedList
{
    int listSize = 0;
    class DoubleLinkedListNode
    {
        Object* item;
        DoubleLinkedListNode* tail = nullptr;
        DoubleLinkedListNode* prevNode = nullptr;
    public:
        DoubleLinkedListNode(Object* item);

        Object* getItem();
        DoubleLinkedListNode* getTail();
        DoubleLinkedListNode* getPrevNode();

        void setTail(DoubleLinkedListNode* tail);
        void setPrevNode(DoubleLinkedListNode* prevNode);
    };
    DoubleLinkedListNode* headNode = nullptr;

    DoubleLinkedListNode* getNode(int pos);
public:
    DoubleLinkedList();

    void add(Object* item);
    Object* remove(int pos);
    Object* get(int pos);
    int size();

    Object* operator[](int pos);
    void operator+=(Object* obj);
};

#endif // DOUBLELINKEDLIST_H
