#include "Queue.h"

template <typename Object>
Queue<Object>::Queue()
{
}
template <typename Object>
Queue<Object>::QueueNode::QueueNode(Object* item)
    : item(item)
{
}
template <typename Object>
Object* Queue<Object>::QueueNode::getItem()
{
    return item;
}
template <typename Object>
typename Queue<Object>::QueueNode* Queue<Object>::QueueNode::getTail()
{
    return tail;
}
template <typename Object>
void Queue<Object>::QueueNode::setItem(Object* item)
{
    this->item = item;
}
template <typename Object>
void Queue<Object>::QueueNode::setTail(Object* tail)
{
    this->tail = new QueueNode(tail);
}
template <typename Object>
void Queue<Object>::QueueNode::setTail(QueueNode* tail)
{
    this->tail = tail;
}
template <typename Object>
void Queue<Object>::add(Object* obj)
{
    if(headNode == nullptr) {
        headNode = new QueueNode(obj);
    }
    else {
        QueueNode* currentNode = headNode;
        while(currentNode->getTail() != nullptr)
            currentNode = currentNode->getTail();
        currentNode->setTail(obj);
    }
    QueueSize++;
}
template <typename Object>
void Queue<Object>::operator+=(Object* obj)
{
    add(obj);
}
template <typename Object>
typename Queue<Object>::QueueNode* Queue<Object>::getNode(int pos)
{
    int posCounter = 0;
    QueueNode* resNode = headNode;
    while(posCounter != pos)
    {
        resNode = resNode->getTail();
        posCounter++;
    }
    return resNode;
}
template <typename Object>
Object* Queue<Object>::remove()
{
    if(QueueSize == 0)
        return nullptr;
    QueueNode* searchingNode = headNode;
    if(QueueSize == 1) {
        headNode = nullptr;
    }
    else {
        headNode = searchingNode->getTail();
    }
    QueueSize--;
    return searchingNode->getItem();
}
template <typename Object>
int Queue<Object>::size()
{
    return QueueSize;
}
