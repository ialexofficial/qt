#include "DoubleLinkedList.h"

template <typename Object>
DoubleLinkedList<Object>::DoubleLinkedList()
{
}
template <typename Object>
DoubleLinkedList<Object>::DoubleLinkedListNode::DoubleLinkedListNode(Object* item)
    : item(item)
{
}
template <typename Object>
Object* DoubleLinkedList<Object>::DoubleLinkedListNode::getItem()
{
    return item;
}
template <typename Object>
typename DoubleLinkedList<Object>::DoubleLinkedListNode* DoubleLinkedList<Object>::DoubleLinkedListNode::getTail()
{
    return tail;
}
template <typename Object>
typename DoubleLinkedList<Object>::DoubleLinkedListNode* DoubleLinkedList<Object>::DoubleLinkedListNode::getPrevNode()
{
    return prevNode;
}
template <typename Object>
void DoubleLinkedList<Object>::DoubleLinkedListNode::setTail(DoubleLinkedListNode* tail)
{
    this->tail = tail;
}
template <typename Object>
void DoubleLinkedList<Object>::DoubleLinkedListNode::setPrevNode(DoubleLinkedListNode* prevNode)
{
    this->prevNode = prevNode;
}
template <typename Object>
void DoubleLinkedList<Object>::add(Object* obj)
{
    if(headNode == nullptr) {
        headNode = new DoubleLinkedListNode(obj);
        headNode->setTail(headNode);
        headNode->setPrevNode(headNode);
    }
    else {
        DoubleLinkedListNode* currentNode = getNode(listSize - 1);
        DoubleLinkedListNode* newNode = new DoubleLinkedListNode(obj);
        currentNode->setTail(newNode);
        newNode->setTail(headNode);
        newNode->setPrevNode(currentNode);
        headNode->setPrevNode(newNode);
    }
    listSize++;
}
template <typename Object>
void DoubleLinkedList<Object>::operator+=(Object* obj)
{
    add(obj);
}
template <typename Object>
typename DoubleLinkedList<Object>::DoubleLinkedListNode* DoubleLinkedList<Object>::getNode(int pos)
{
    if(listSize == 0)
        throw std::out_of_range("Out of range");
    int posCounter = 0;
    DoubleLinkedListNode* resNode = headNode;
    while(posCounter != pos)
    {
        resNode = resNode->getTail();
        posCounter++;
    }
    return resNode;
}
template <typename Object>
Object* DoubleLinkedList<Object>::get(int pos)
{
    return getNode(pos)->getItem();
}
template <typename Object>
Object* DoubleLinkedList<Object>::remove(int pos)
{
    DoubleLinkedListNode* searchingNode = getNode(pos);
    searchingNode->getPrevNode()->setTail(searchingNode->getTail());
    listSize--;
    return searchingNode->getItem();
}
template <typename Object>
Object* DoubleLinkedList<Object>::operator[](int pos)
{
    return get(pos);
}
template <typename Object>
int DoubleLinkedList<Object>::size()
{
    return listSize;
}
