#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , images()
    , timer(this)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    images.add(new QPixmap("D:\\labs\\qt\\lab5_1\\frame1.jpg"));
    images.add(new QPixmap("D:\\labs\\qt\\lab5_1\\frame2.jpg"));
    images.add(new QPixmap("D:\\labs\\qt\\lab5_1\\frame3-5.jpg"));
    images.add(new QPixmap("D:\\labs\\qt\\lab5_1\\frame4.jpg"));
    images.add(new QPixmap("D:\\labs\\qt\\lab5_1\\frame5.jpg"));
    images.add(new QPixmap("D:\\labs\\qt\\lab5_1\\frame6.jpg"));
    images.add(new QPixmap("D:\\labs\\qt\\lab5_1\\frame3-5.jpg"));
    images.add(new QPixmap("D:\\labs\\qt\\lab5_1\\frame7.jpg"));

    ui->label->setPixmap(*images[imageCounter++]);

    timer.start(1000/10);
    connect(&timer, SIGNAL(timeout()), this, SLOT(advance()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::advance()
{
    ui->label->setPixmap(*images[imageCounter++]);
}
