#ifndef Queue_H
#define Queue_H

template <typename Object>
class Queue
{
    class QueueNode
    {
        Object* item;
        QueueNode* tail = nullptr;
    public:
        QueueNode(Object* item);

        Object* getItem();
        QueueNode* getTail();

        void setItem(Object* item);
        void setTail(Object* tail);
        void setTail(QueueNode* tail);
    };
    int QueueSize = 0;
    QueueNode* headNode = nullptr;

    QueueNode* getNode(int pos);
public:

    Queue();

    void add(Object* obj);
    Object* remove();
    int size();

    void operator+=(Object* obj);

};


#endif // Queue_H
