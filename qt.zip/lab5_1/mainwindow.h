#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPixmap>
#include <QTimer>
#include "queue.h"
#include "queue.cpp"
#include "doublelinkedlist.h"
#include "doublelinkedlist.cpp"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

template class DoubleLinkedList<QPixmap>;

class MainWindow : public QMainWindow
{
    Q_OBJECT
    DoubleLinkedList<QPixmap> images;
    int imageCounter = 0;
    QTimer timer;

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
private slots:
    void advance();
private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
