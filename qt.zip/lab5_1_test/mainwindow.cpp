#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , images()
    , timer(this)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    fillQueue();

    ui->label->setPixmap(*images[imageCounter++]);

    timer.start(100);
    connect(&timer, SIGNAL(timeout()), this, SLOT(advance()));
}

void MainWindow::fillQueue()
{
    images.add(new QPixmap("D:\\labs\\qt\\lab5_1\\frame1.jpg"));
    images.add(new QPixmap("D:\\labs\\qt\\lab5_1\\frame2.jpg"));
    images.add(new QPixmap("D:\\labs\\qt\\lab5_1\\frame3-5.jpg"));
    images.add(new QPixmap("D:\\labs\\qt\\lab5_1\\frame4.jpg"));
    images.add(new QPixmap("D:\\labs\\qt\\lab5_1\\frame5.jpg"));
    images.add(new QPixmap("D:\\labs\\qt\\lab5_1\\frame6.jpg"));
    images.add(new QPixmap("D:\\labs\\qt\\lab5_1\\frame3-5.jpg"));
    images.add(new QPixmap("D:\\labs\\qt\\lab5_1\\frame7.jpg"));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::advance()
{
    try
    {
        ui->label->setPixmap(*images[imageCounter++]);
        if(imageCounter < 0)
            imageCounter = 0;
    }
    catch(std::out_of_range)
    {
        ui->label->setPixmap(*new QPixmap());
        showErrorMessage("Пустая очередь");
        timer.stop();
    }
}



void MainWindow::showErrorMessage(QString str)
{
    QMessageBox box;
    box.setText(str);
    box.exec();
}

void MainWindow::on_pushButton_clicked()
{
    try
    {
        ui->label_2->setPixmap(*images[0]);
    }
    catch(std::out_of_range)
    {
        ui->label_2->setPixmap(*new QPixmap());
        showErrorMessage("Пустая очередь");
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    try
    {
        ui->label_2->setPixmap(*images.remove(0));
    }
    catch(std::out_of_range)
    {
        ui->label_2->setPixmap(*new QPixmap());
        showErrorMessage("Пустая очередь");
    }
}
void MainWindow::on_pushButton_5_clicked()
{
    timer.stop();
}

void MainWindow::on_pushButton_4_clicked()
{
    while(images.size() != 0)
        images.remove(0);
    fillQueue();
    imageCounter = 0;
    timer.start();
}

void MainWindow::on_pushButton_6_clicked()
{
    timer.start();
}

void MainWindow::on_pushButton_3_clicked()
{
    // Выбираем файл
    QString fileName = QFileDialog::getOpenFileName(this,
                                                       tr("Open Json File"),
                                                       QString(),
                                                        tr("Images (*.png *.xpm *.jpg)"));
            ;
    images.add(new QPixmap(fileName));
}
