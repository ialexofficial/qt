#include "doublelinkedlist.h"
template <typename Object>
DoubleLinkedList<Object>::DoubleLinkedList()
{
}
template <typename Object>
void DoubleLinkedList<Object>::add(Object* obj)
{
    if(Queue<Object>::headNode == nullptr) {
        Queue<Object>::headNode = new typename Queue<Object>::QueueNode(obj);
        Queue<Object>::headNode->setTail(Queue<Object>::headNode);
    }
    else {
        typename Queue<Object>::QueueNode* currentNode = getNode(Queue<Object>::queueSize - 1);
        typename Queue<Object>::QueueNode* newNode = new typename Queue<Object>::QueueNode(obj);
        currentNode->setTail(newNode);
        newNode->setTail(Queue<Object>::headNode);
    }
    Queue<Object>::queueSize++;
}
template <typename Object>
void DoubleLinkedList<Object>::operator+=(Object* obj)
{
    add(obj);
}
template <typename Object>
typename Queue<Object>::QueueNode* DoubleLinkedList<Object>::getNode(int pos)
{
    if(Queue<Object>::queueSize == 0)
        throw std::out_of_range("Out of range");
    int posCounter = 0;
    typename Queue<Object>::QueueNode* resNode = Queue<Object>::headNode;
    while(posCounter != pos)
    {
        resNode = resNode->getTail();
        posCounter++;
    }
    return resNode;
}
template <typename Object>
Object* DoubleLinkedList<Object>::get(int pos)
{
    return getNode(pos)->getItem();
}
template <typename Object>
Object* DoubleLinkedList<Object>::remove(int pos)
{
    typename Queue<Object>::QueueNode* searchingNode = getNode(pos);
    if(Queue<Object>::queueSize == 1)
        Queue<Object>::headNode = nullptr;
    else if(pos == 0)
        Queue<Object>::headNode = searchingNode->getTail();
    searchingNode->getPrevNode()->setTail(searchingNode->getTail());
    Queue<Object>::queueSize--;
    return searchingNode->getItem();
}
template <typename Object>
Object* DoubleLinkedList<Object>::operator[](int pos)
{
    return get(pos);
}
