#ifndef Queue_H
#define Queue_H

#include <stdexcept>

template <typename Object>
class Queue
{
protected:
    class QueueNode
    {
        Object* item;
        QueueNode* tail = nullptr;
        QueueNode* prevNode = nullptr;
    public:
        QueueNode(Object* item);

        Object* getItem();
        QueueNode* getTail();
        QueueNode* getPrevNode();

        void setItem(Object* item);
        void setTail(QueueNode* tail);
        void setPrevNode(QueueNode* prevNode);
    };
    int queueSize = 0;
    QueueNode* headNode = nullptr;
public:

    Queue();

    virtual void add(Object* obj);
    Object* remove();
    int size();

    virtual void operator+=(Object* obj);

};


#endif // Queue_H
