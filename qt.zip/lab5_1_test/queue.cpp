#include "queue.h"

template <typename Object>
Queue<Object>::Queue()
{
}
template <typename Object>
Queue<Object>::QueueNode::QueueNode(Object* item)
    : item(item)
{
}
template <typename Object>
Object* Queue<Object>::QueueNode::getItem()
{
    return item;
}
template <typename Object>
typename Queue<Object>::QueueNode* Queue<Object>::QueueNode::getTail()
{
    return tail;
}
template <typename Object>
typename Queue<Object>::QueueNode* Queue<Object>::QueueNode::getPrevNode()
{
    return prevNode;
}
template <typename Object>
void Queue<Object>::QueueNode::setItem(Object* item)
{
    this->item = item;
}
template <typename Object>
void Queue<Object>::QueueNode::setTail(QueueNode* tail)
{
    this->tail = tail;
    if(tail != nullptr)
        tail->setPrevNode(this);
}
template <typename Object>
void Queue<Object>::QueueNode::setPrevNode(QueueNode* prevNode)
{
    this->prevNode = prevNode;
}
template <typename Object>
void Queue<Object>::add(Object* obj)
{
    if(headNode == nullptr) {
        headNode = new QueueNode(obj);
    }
    else {
        QueueNode* currentNode = headNode;
        while(currentNode->getTail() != nullptr)
            currentNode = currentNode->getTail();
        currentNode->setTail(new QueueNode(obj));
    }
    queueSize++;
}
template <typename Object>
void Queue<Object>::operator+=(Object* obj)
{
    add(obj);
}
template <typename Object>
Object* Queue<Object>::remove()
{
    if(queueSize == 0)
        throw std::out_of_range("Queue is empty");
    QueueNode* searchingNode = headNode;
    if(queueSize == 1) {
        headNode = nullptr;
        headNode->setTail(nullptr);
    }
    else {
        headNode = searchingNode->getTail();
        headNode->setPrevNode(nullptr);
    }
    queueSize--;
    return searchingNode->getItem();
}
template <typename Object>
int Queue<Object>::size()
{
    return queueSize;
}
