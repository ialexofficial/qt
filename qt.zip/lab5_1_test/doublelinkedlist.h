#ifndef DOUBLELINKEDLIST_H
#define DOUBLELINKEDLIST_H

#include <stdexcept>
#include "queue.h"
#include "queue.cpp"

template <typename Object>
class DoubleLinkedList: public Queue<Object>
{
public:
    DoubleLinkedList();

    typename Queue<Object>::QueueNode* getNode(int pos);
    void add(Object* obj) override;
    Object* remove(int pos);
    Object* get(int pos);

    void operator+=(Object* obj) override;
    Object* operator[](int pos);
};

#endif // DOUBLELINKEDLIST_H
