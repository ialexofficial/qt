#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPixmap>
#include <QTimer>
#include <QMessageBox>
#include <QFileDialog>
#include "doublelinkedlist.h"
#include "doublelinkedlist.cpp"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

template class DoubleLinkedList<QPixmap>;

class MainWindow : public QMainWindow
{
    Q_OBJECT
    DoubleLinkedList<QPixmap> images;
    char imageCounter = 0;
    QTimer timer;

    void showErrorMessage(QString str);
    void fillQueue();

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
private slots:
    void advance();
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();


    void on_pushButton_5_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
