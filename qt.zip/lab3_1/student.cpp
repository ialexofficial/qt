#include "student.h"

Student::Student(QString fullName, QString group, float averageMark, float familySalary)
    : fullName(fullName)
    , group(group)
    , averageMark(averageMark)
    , familySalary(familySalary)
{

}
QString Student::getFullName()
{
    return fullName;
}
QString Student::getGroup()
{
    return group;
}
float Student::getAverageMark()
{
    return averageMark;
}
float Student::getFamilySalary()
{
    return familySalary;
}

void Student::setFullName(QString fullName)
{
    this->fullName = fullName;
}
void Student::setGroup(QString group)
{
    this->group = group;
}
void Student::setAverageMark(float averageMark)
{
    this->averageMark = averageMark;
}
void Student::setFamilySalary(float salary)
{
    this->familySalary = salary;
}
