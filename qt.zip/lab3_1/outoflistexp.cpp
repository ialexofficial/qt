#include "outoflistexp.h"

OutOfListExp::OutOfListExp(const char* error_msg)
    : error_msg(error_msg)
{

}
const char* OutOfListExp::what() const _GLIBCXX_TXN_SAFE_DYN _GLIBCXX_USE_NOEXCEPT
{
    return error_msg;
}
