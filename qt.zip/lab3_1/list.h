#ifndef LIST_H
#define LIST_H

#include <stdexcept>
#include "outoflistexp.h"

template <class Object>
class ListNode
{
    Object* item;
    ListNode<Object>* tail = nullptr;
public:
    ListNode(Object* item);

    Object* getItem();
    ListNode<Object>* getTail();

    void setItem(Object* item);
    void setTail(Object* tail);
    void setTail(ListNode<Object>* tail);
};
template <class Object>
class List
{
    int listSize = 0;
    ListNode<Object>* headNode = nullptr;

    ListNode<Object>* getNode(int pos);
public:

    List();

    void add(Object* obj);
    Object* remove(int pos);
    Object* get(int pos);
    int size();

    Object* operator[](int pos);
    void operator+=(Object* obj);

};

#endif // LIST_H
