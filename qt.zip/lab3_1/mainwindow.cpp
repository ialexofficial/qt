#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , studentsList()
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->tableWidget->setColumnCount(4);
    setTableHeader();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setTableHeader()
{
    QTableWidgetItem* tempItem;
    tempItem = new QTableWidgetItem("ФИО");
    ui->tableWidget->setHorizontalHeaderItem(0, tempItem);
    tempItem = new QTableWidgetItem("Группа");
    ui->tableWidget->setHorizontalHeaderItem(1, tempItem);
    tempItem = new QTableWidgetItem("Средняя оценка");
    ui->tableWidget->setHorizontalHeaderItem(2, tempItem);
    tempItem = new QTableWidgetItem("Доход на члена семьи");
    ui->tableWidget->setHorizontalHeaderItem(3, tempItem);
}

void MainWindow::on_pushButton_4_clicked()
{
    // add student
    QString fullName = ui->lineEdit->text();
    QString group = ui->lineEdit_2->text();
    float averageMark = ui->doubleSpinBox_4->value();
    float familySalary = ui->doubleSpinBox_5->value();
    if(
        fullName == "" ||
        group == "" ||
        group.contains(QRegExp("\\D"))
    ) {
        QMessageBox box;
        box.setText("Проверьте корректность полей");
        box.exec();
    }
    else {
        Student* student = new Student(fullName, group, averageMark, familySalary);
        studentsList += student;
    }
    updateFields();
}

void MainWindow::on_pushButton_5_clicked()
{
    // delete student
    int pos = ui->spinBox->value();
    try {
        delete studentsList.remove(pos - 1);
    }
    catch(OutOfListExp) {
        QMessageBox box;
        box.setText("Проверьте корректность полей");
        box.exec();
    }

    updateFields();
}

void MainWindow::on_pushButton_clicked()
{
    // filter by family salary
    filterType = 1;
    updateFields();
}

void MainWindow::on_pushButton_2_clicked()
{
    // filter by average mark
    filterType = 2;
    updateFields();
}

void MainWindow::on_pushButton_3_clicked()
{
    // remove filter
    filterType = 0;
    updateFields();
}
void MainWindow::updateFields()
{
    ui->tableWidget->clear();
    setTableHeader();
    int rowCounter = 0;
    if(filterType == 1) {
        float minSalary = ui->doubleSpinBox->value();
        for(int i = 0; i < studentsList.size(); i++)
        {
            if(studentsList[i]->getFamilySalary() >= minSalary)
                addToTable(studentsList[i], rowCounter++);
        }
    }
    else if(filterType == 2) {
        float minSalary = ui->doubleSpinBox_2->value() * 2;
        float minMark = ui->doubleSpinBox_3->value();
        for(int i = 0; i < studentsList.size(); i++)
        {
            if(studentsList[i]->getFamilySalary() >= minSalary && studentsList[i]->getAverageMark() >= minMark)
                addToTable(studentsList[i], rowCounter++);
        }
    }
    else {
        for(int i = 0; i < studentsList.size(); i++)
        {
            addToTable(studentsList[i], rowCounter++);
        }
    }
}
void MainWindow::addToTable(Student* student, int row)
{
    ui->tableWidget->setRowCount(row + 1);
    setTableHeader();
    QTableWidgetItem* tempItem;
    QString tempString;
    tempItem = new QTableWidgetItem(student->getFullName());
    ui->tableWidget->setItem(row, 0, tempItem);
    tempItem = new QTableWidgetItem(student->getGroup());
    ui->tableWidget->setItem(row, 1, tempItem);
    tempItem = new QTableWidgetItem(tempString.setNum(student->getAverageMark(), 10, 1));
    ui->tableWidget->setItem(row, 2, tempItem);
    tempItem = new QTableWidgetItem(tempString.setNum(student->getFamilySalary(), 10, 2));
    ui->tableWidget->setItem(row, 3, tempItem);
}
