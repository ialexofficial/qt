#ifndef OUTOFLISTEXP_H
#define OUTOFLISTEXP_H

#include <string>

class OutOfListExp : public std::exception
{
    const char* error_msg;
public:
    OutOfListExp(const char* error_msg);

    const char* what() const _GLIBCXX_TXN_SAFE_DYN _GLIBCXX_USE_NOEXCEPT;
};

#endif // OUTOFLISTEXP_H
