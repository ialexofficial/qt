#ifndef STUDENT_H
#define STUDENT_H

#include <QString>

class Student
{

    QString fullName, group;
    float averageMark, familySalary;
public:
    Student(QString fullName, QString group, float averageMark, float familySalary);

    QString getFullName();
    QString getGroup();
    float getAverageMark();
    float getFamilySalary();

    void setFullName(QString fullName);
    void setGroup(QString group);
    void setAverageMark(float averageMark);
    void setFamilySalary(float salary);
};

#endif // STUDENT_H
