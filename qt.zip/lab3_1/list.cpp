#include "list.h"

template <class Object>
List<Object>::List()
{
}
template <class Object>
ListNode<Object>::ListNode(Object* item)
    : item(item)
{
}
template <class Object>
Object* ListNode<Object>::getItem()
{
    return item;
}
template <class Object>
ListNode<Object>* ListNode<Object>::getTail()
{
    return tail;
}
template <class Object>
void ListNode<Object>::setItem(Object* item)
{
    this->item = item;
}
template <class Object>
void ListNode<Object>::setTail(Object* tail)
{
    this->tail = new ListNode<Object>(tail);
}
template <class Object>
void ListNode<Object>::setTail(ListNode<Object>* tail)
{
    this->tail = tail;
}
template <class Object>
void List<Object>::add(Object* obj)
{
    if(headNode == nullptr) {
        headNode = new ListNode<Object>(obj);
    }
    else {
        ListNode<Object>* currentNode = headNode;
        while(currentNode->getTail() != nullptr)
            currentNode = currentNode->getTail();
        currentNode->setTail(obj);
    }
    listSize++;
}
template <class Object>
void List<Object>::operator+=(Object* obj)
{
    add(obj);
}
template <class Object>
ListNode<Object>* List<Object>::getNode(int pos)
{
    if(abs(pos) >= listSize)
        throw OutOfListExp("Out of list range");
    if(pos < 0)
        pos = listSize + pos;
    int posCounter = 0;
    ListNode<Object>* resNode = headNode;
    while(posCounter != pos)
    {
        resNode = resNode->getTail();
        posCounter++;
    }
    return resNode;
}
template <class Object>
Object* List<Object>::get(int pos)
{
    return getNode(pos)->getItem();
}
template <class Object>
Object* List<Object>::operator[](int pos)
{
    return get(pos);
}
template <class Object>
Object* List<Object>::remove(int pos)
{
    if(abs(pos) >= listSize) {
        throw OutOfListExp("Out of list range");
    }
    if(pos < 0) {
        pos = listSize + pos;
    }
    ListNode<Object>* searchingNode;
    if(listSize == 1) {
        searchingNode = headNode;
        headNode = nullptr;
    }
    else {
        searchingNode = getNode(pos);
        ListNode<Object>* previousNode = getNode(pos - 1);
        if(searchingNode == headNode)
            headNode = searchingNode->getTail();
        else
            previousNode->setTail(searchingNode->getTail());
    }
    listSize--;
    return searchingNode->getItem();
}
template <class Object>
int List<Object>::size()
{
    if(headNode == nullptr)
        return 0;
    int res = 1;
    ListNode<Object>* currentNode = headNode;
    while(currentNode->getTail() != nullptr)
    {
        currentNode = currentNode->getTail();
        res++;
    }
    return res;
}
