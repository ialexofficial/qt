#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "student.h"
#include "list.h"
#include "list.cpp"
#include <QString>
#include <QRegExp>
#include <QMessageBox>
#include <QTableWidget>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

template class List<Student>;

class MainWindow : public QMainWindow
{
    Q_OBJECT
    List<Student> studentsList;
    int filterType = 0;

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    void updateFields();
    void addToTable(Student* student, int row);
    void setTableHeader();

    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
