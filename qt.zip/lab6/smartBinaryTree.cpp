#ifndef SMARTBINARYTREE
#define SMARTBINARYREE

#include "binaryTree.cpp"

template <typename Object>
class SmartBinaryTree : public BinaryTree<Object>
{
public:
    SmartBinaryTree(int key, Object* item)
        : BinaryTree<Object>(key, item)
    {}
    SmartBinaryTree()
    {}

    SmartPtr<Object>* findMiddliest()
    {
        SmartPtr<Object>** objs = new SmartPtr<Object>*[BinaryTree<Object>::size];
        int* keys = new int[BinaryTree<Object>::size];
        BinaryTree<Object>::_inOrder(objs, 0, BinaryTree<Object>::root, keys);
        int middle = 0, best_res = keys[0], pos = 0;
        for(int i = 0; i < BinaryTree<Object>::size; i++)
        {
            middle += keys[i];
        }
        middle /= BinaryTree<Object>::size;
        for(int i = 1; i < BinaryTree<Object>::size; i++)
            if(abs(middle - keys[i]) < abs(middle - best_res)) {
                best_res = keys[i];
                pos = i;
            }
        return objs[pos];
    }
};
#endif
