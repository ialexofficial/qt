#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , tree()
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    scene = new  QGraphicsScene(0, 0, 321, 291, this);
    ui->graphicsView->setScene(scene);
}


void MainWindow::_showBranch(BinaryTree<QString>::BinaryTreeNode* root, int x, int y)
{
    scene->addText((QString)"key: " + (QString)root->getKey() + (QString)"\nText: " + root->item->getItem());
    if(root->left_child != nullptr)
        _showBranch(root->left_child, x - 50, y + 50);
    if(root->right_child != nullptr)
        _showBranch(root->right_child, x + 50, y + 50);
}
void MainWindow::displayTree()
{
    scene->clear();
    _showBranch(tree.getRoot(), 160, 0);
}


MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    tree.add(ui->spinBox->value(), new QString(ui->lineEdit->text()));
    displayTree();
}
