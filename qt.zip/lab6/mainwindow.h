#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsScene>
#include "smartBinaryTree.cpp"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

template class SmartBinaryTree<QString>;

class MainWindow : public QMainWindow
{
    Q_OBJECT

    SmartBinaryTree<QString> tree;

    QGraphicsScene* scene;

    void displayTree();
    void _showBranch(BinaryTree<QString>::BinaryTreeNode* root, int x, int y);

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
