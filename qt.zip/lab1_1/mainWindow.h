#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <balloon.h>

#include <QGraphicsView>
#include <QMouseEvent>
#include <iostream>

class MainWindow : public QGraphicsView {

    Q_OBJECT
    Balloon *scene;

public:
    MainWindow(Balloon *scene);
    ~MainWindow();

    void create_balloon(qreal x, qreal y);

private:
    void mousePressEvent(QMouseEvent *event);
};

#endif // MAINWINDOW_H
