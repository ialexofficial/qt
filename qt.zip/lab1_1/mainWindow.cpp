#include <mainWindow.h>
#include "ui_mainWindow.h"

MainWindow::MainWindow(Balloon *scene)
    : QGraphicsView(scene)
{
    setFixedSize(800, 800);
    setHorizontalScrollBarPolicy ( Qt::ScrollBarAlwaysOff );
    setVerticalScrollBarPolicy ( Qt::ScrollBarAlwaysOff );
    this->scene = scene;
}

MainWindow::~MainWindow()
{
}
void MainWindow::mousePressEvent(QMouseEvent *event) {
    scene->pressMouseEvent(mapToScene(event->pos()));
}
