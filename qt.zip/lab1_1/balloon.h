#ifndef BALLOON_H
#define BALLOON_H

#include <ellipse.h>
#include <QPainter>
#include <math.h>
#include <ctime>

class Balloon: public Ellipse
{
    Q_OBJECT

public:
    Balloon(QObject *parent = nullptr);
    Balloon(qreal x, qreal y, qreal width, qreal height, QObject *parent = nullptr);
    ~Balloon();

    void pressMouseEvent(QPointF pos);
    QGraphicsEllipseItem* draw_balloon(qreal x, qreal y, QPen pen, QBrush brush);
};

#endif // BALLOON_H
