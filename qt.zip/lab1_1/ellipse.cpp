#include "ellipse.h"
#include "ui_ellipse.h"
#include <iostream>


Ellipse::Ellipse(QObject *parent)
    : QGraphicsScene(parent)
{
}
Ellipse::Ellipse(qreal x, qreal y, qreal width, qreal height, QObject *parent)
    : QGraphicsScene(x, y, width, height, parent)
{
}

Ellipse::~Ellipse()
{
}
QGraphicsEllipseItem* Ellipse::draw_ellipse(qreal x, qreal y, qreal width, qreal height, QPen pen, QBrush brush)
{
    qreal centerX = x - width / 2;
    qreal centerY = y - height / 2;
    return addEllipse(centerX, centerY, width, height, pen, brush);
}

void Ellipse::start_ellipse_moving(QGraphicsItem *item)
{
    QTimeLine *timer = new QTimeLine(10000);
    timer->setFrameRange(0, 100);

    QGraphicsItemAnimation *animation = new QGraphicsItemAnimation;
    animation->setItem(item);
    animation->setTimeLine(timer);
    for (int i = 0; i < 1000; ++i) {
        animation->setPosAt(i / 1000.0, QPointF(0 , -i));
    }

    timer->start();
}
