#include "mainWindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Balloon scene(0, 0, 800, 800);

    MainWindow window(&scene);
    window.show();
    return a.exec();
}
