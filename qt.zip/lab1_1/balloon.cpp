#include <balloon.h>

Balloon::Balloon(QObject *parent)
    : Ellipse(parent)
{
}
Balloon::Balloon(qreal x, qreal y, qreal width, qreal height, QObject *parent)
    : Ellipse(x, y, width, height, parent)
{
}
Balloon::~Balloon()
{
}

void Balloon::pressMouseEvent(QPointF pos)
{
    QGraphicsItem *item = itemAt(pos, QTransform());
    if(item != nullptr && item->isVisible()) {
        item->hide();
    }
    else {
        srand(time(0));
        int color_arr[3] = {rand() % 256, rand() % 256, rand() % 256};
        start_ellipse_moving(draw_balloon(pos.x(), pos.y(), QPen(QColor(color_arr[0], color_arr[1], color_arr[2])), QBrush(QColor(color_arr[0], color_arr[1], color_arr[2]))));
    }
}
QGraphicsEllipseItem* Balloon::draw_balloon(qreal x, qreal y, QPen pen, QBrush brush)
{
    QGraphicsEllipseItem *ell = draw_ellipse(x, y, 150, 200, pen, brush);
    for(int i = 0, j = y + 100; j < y + 200; i += 100, j++) {
        QGraphicsLineItem *line = addLine(x + 2*sin(i), j, x + 2*sin(i + 100), j + 1);
        line->setParentItem(ell);
    }
    return ell;
}
