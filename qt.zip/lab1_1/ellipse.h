#ifndef ELLIPSE_H
#define ELLIPSE_H

#include <QGraphicsScene>
#include <QGraphicsSceneMouseEvent>
#include <QGraphicsItem>
#include <QGraphicsEllipseItem>
#include <QTimeLine>
#include <QGraphicsItemAnimation>

class Ellipse : public QGraphicsScene
{
    Q_OBJECT
    std::vector<QGraphicsItem*> items;
    std::vector<QTimeLine*> timers;
public:
    Ellipse(QObject *parent = nullptr);
    Ellipse(qreal x, qreal y, qreal width, qreal height, QObject *parent = nullptr);
    ~Ellipse();

    QGraphicsEllipseItem* draw_ellipse(qreal x, qreal y, qreal width, qreal height, QPen pen, QBrush brush);
    void start_ellipse_moving(QGraphicsItem *item);
    void moveBy(QGraphicsItem *item);
};
#endif // ELLIPSE_H
