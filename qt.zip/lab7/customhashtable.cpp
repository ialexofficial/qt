#ifndef CUSTOMHASHTABLE
#define CUSTOMHASHTABLE

#include "hashTable.cpp"

class CustomHashTable : public HashTable
{
public:
    CustomHashTable(int size)
        : HashTable(size)
    {}

    List<Pair> getLowerKey(int key)
    {
        List<Pair> res;
        for(int i = 0; i < size; i++)
        {
            for(int j = 0; j < array[i]->size(); j++)
            {
                Pair* tmp = array[i]->get(j);
                if(tmp->key < key)
                    res += tmp;
            }
        }
        return res;
    }
    List<Pair> getHigherKey(int key)
    {
        List<Pair> res;
        for(int i = 0; i < size; i++)
        {
            for(int j = 0; j < array[i]->size(); j++)
            {
                Pair* tmp = array[i]->get(j);
                if(tmp->key > key)
                    res += tmp;
            }
        }
        return res;
    }
};


#endif
